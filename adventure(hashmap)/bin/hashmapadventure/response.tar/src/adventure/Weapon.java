package adventure;
// TODO: Komplettering: när ett item används ska det hända något som påverkar spelet, det ska inte endast skrivas ut något
// exemeplvis kan spelaren få mer hälsa eller liknande
public class Weapon extends Item {

	public Weapon(String name, String takeAction, double weight) {
		super(name, takeAction, weight);

	}

	public boolean doCommand(String cmd, Player player) {

		System.out.println("You swing you sword through the air");

		return true;

	}

}
